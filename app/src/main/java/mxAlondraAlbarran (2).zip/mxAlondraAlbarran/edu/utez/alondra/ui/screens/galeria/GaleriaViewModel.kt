package mxAlondraAlbarran.edu.utez.alondra.ui.screens.galeria

class GaleriaViewModel {
}