package mx.edu.utez.alondra.ui.screens.calculadora

import androidx.compose.material3.Button
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    onBanckClick: () -> Unit
){
    var displayText by remember { mutableStateOf("") }
    var firstNumber by remember { mutableStateOf<Double?>(null) }
    var pendingOperation by remember { mutableStateOf<String?>(null) }
    var isNewInput by remember { mutableStateOf(false) }

    fun onNumberClick (digit: String){
        if (isNewInput){
            displayText = digit
            isNewInput = false
        }else{
            displayText += digit
        }
    }

    fun onDotClick(){
        if (isNewInput){
            displayText = "0."
            isNewInput = false
        } else if (!displayText.contains(".")){
            displayText = if (displayText.isEmpty()) "0." else "$displayText."
        }
    }

    fun onOperationClick(op: String){
        val currentVal = displayText.toDoubleOrNull()
        if (currentVal != null){
            firstNumber = currentVal
            pendingOperation = op
            isNewInput = true
        }
    }

    fun onEqualsClick(){
        val secondVal = displayText.toDoubleOrNull()
        val firstVal = firstNumber

        if (firstVal != null && secondVal != null && pendingOperation != null){
            val result = when (pendingOperation){
                "+" -> firstVal + secondVal
                "-" -> firstVal - secondVal
                "*" -> firstVal * secondVal
                "/" -> if (secondVal != 0.0) firstVal / secondVal else Double.NaN
                else -> 0.0
            }
            displayText = if (result.isNaN()){
                "error"
            }else if (result % 1.0 == 0.0){
                result.toLong().toString()

            }else{
                result.toString()
            }

            firstNumber = null
            pendingOperation = null
            isNewInput = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calculadoraaa") },
                navigationIcon = {
                    IconButton(onClick = onBanckClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "regresar"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxSize().padding(paddingValues).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value =  displayText,
                onValueChange = { displayText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                readOnly = true,
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 28.sp,
                    textAlign = TextAlign.End
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            val buttonGrid = listOf(
                listOf("7", "8", "9", "/"),
                listOf("4", "5", "6", "*"),
                listOf("1", "2", "3", "-"),
                listOf("0", "+", ".", "="),
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                for (row in buttonGrid){
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (symbol in row){
                            Button(
                                onClick = {
                                    when (symbol){
                                        in "0".."9"-> onNumberClick(symbol)
                                        "." -> onDotClick()
                                        "=" -> onEqualsClick()
                                        else -> onOperationClick(symbol)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(64.dp),
                                shape = RoundedCornerShape(12.dp)
                            ){
                                Text(
                                    text = symbol,
                                    fontSize = 22.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

